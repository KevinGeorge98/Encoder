# platform detection code is now in gaugette.platform
